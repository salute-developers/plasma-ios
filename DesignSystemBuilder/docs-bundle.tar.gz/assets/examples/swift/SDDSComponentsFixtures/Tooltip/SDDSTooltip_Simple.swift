Image(systemName: "info.circle")
    .tooltip(
        isPresented: $isPresented,
        appearance: Tooltip.m.appearance,
        width: nil,
        text: "Текст подсказки",
        placement: .top,
        alignment: .start,
        tailEnabled: true
    ) {
        Image(systemName: "info.circle")
    }
