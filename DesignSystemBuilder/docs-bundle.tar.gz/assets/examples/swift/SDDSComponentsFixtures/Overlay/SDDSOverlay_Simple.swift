SDDSOverlay(isPresented: $isPresented, appearance: Overlay.default.appearance) {
    Text("Content")
}
