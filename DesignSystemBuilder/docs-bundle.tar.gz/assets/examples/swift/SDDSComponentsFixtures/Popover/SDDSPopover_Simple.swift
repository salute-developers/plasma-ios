Text("Показать popover")
    .popover(
        isPresented: $isPresented,
        appearance: Popover.m.appearance,
        placement: .bottom,
        alignment: .start,
        tailEnabled: true
    ) {
        Text("Контент popover")
    }
