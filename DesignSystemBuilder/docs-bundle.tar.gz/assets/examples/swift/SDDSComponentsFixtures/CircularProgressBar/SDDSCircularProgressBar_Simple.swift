SDDSCircularProgressBar(progress: 0.75, appearance: CircularProgressBar.l.default.appearance)
