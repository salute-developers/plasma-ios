SDDSModal(
    content: { Text("Content") },
    closeImage: nil,
    appearance: Modal.default.appearance,
    onClose: {}
)
