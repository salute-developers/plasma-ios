SDDSTextSkeleton(appearance: TextSkeleton.default.appearance)
