SDDSSelect(
    triggerStyle: .textField(TextFieldData(
        title: "City",
        placeholder: "Select city",
        appearance: SelectSingleNormal.l.appearance.textFieldAppearance
    )),
    text: selectedTitle,
    appearance: SelectSingleNormal.l.appearance,
    isDropdownPresented: $isDropdownPresented,
    options: options,
    selectionMode: .single,
    onOptionTap: { index in
        handleSingleSelection(at: index)
    }
)
