SDDSSelect(
    triggerStyle: .button(
        ButtonData(
            title: "Select cities",
            appearance: SelectMultipleNormal.l.appearance.buttonAppearance,
            layoutMode: .fixedWidth(.packed),
            action: {}
        )
    ),
    chips: chips,
    appearance: SelectMultipleNormal.l.appearance,
    isDropdownPresented: $isDropdownPresented,
    options: options,
    selectionMode: .multiple,
    onOptionTap: { index in
        handleMultipleSelection(at: index)
    }
)
.frame(width: 280, alignment: .leading)
