SDDSDrawer(
    appearance: DrawerCloseOuter.m.appearance,
    backgroundColor: nil,
    onClose: nil,
    closePlacement: .right,
    hasHeader: false,
    hasFooter: false,
    header: { EmptyView() },
    content: { Text("Content") },
    footer: { EmptyView() }
)
