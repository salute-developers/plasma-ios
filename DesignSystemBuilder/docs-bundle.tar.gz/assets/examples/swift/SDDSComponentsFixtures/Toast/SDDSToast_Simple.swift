SDDSToast(
    text: "Текст тоста",
    contentEndPosition: .topRight,
    onClose: nil
)
