SDDSIcon(
    Image(systemName: "heart.fill"),
    fillStyle: .color(ColorToken.textDefaultAccent),
    sideLength: 32
)
