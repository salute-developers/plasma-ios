SDDSIcon(
    Image(systemName: "star.fill"),
    fillStyle: .gradient(GradientToken.surfaceDefaultAccentGradient),
    sideLength: 32
)
