SDDSAvatarGroup(
    data: Self.exampleAvatars,
    lastAvatar: Self.lastAvatarData,
    maxDisplayingAvatarCount: 3
)
