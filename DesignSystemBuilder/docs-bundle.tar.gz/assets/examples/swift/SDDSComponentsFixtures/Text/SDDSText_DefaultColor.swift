SDDSText(
    "Sample label",
    fillStyle: .color(ColorToken.textDefaultPrimary)
)
