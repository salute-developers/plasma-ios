SDDSText(
    "Gradient title",
    fillStyle: .gradient(GradientToken.textDefaultAccentGradient)
)
