SDDSAccordion(
    items: [
        AccordionData(
            title: "Первый элемент",
            content: "Содержимое первого элемента"
        ),
        AccordionData(
            title: "Второй элемент",
            content: "Содержимое второго элемента"
        )
    ],
    showDividers: false,
    appearance: AccordionSolidActionStart.m.appearance
)
