SDDSImage(
    image: Image(systemName: "photo"),
    appearance: Image.ratio_16_9.appearance
)
.frame(maxWidth: 200)
