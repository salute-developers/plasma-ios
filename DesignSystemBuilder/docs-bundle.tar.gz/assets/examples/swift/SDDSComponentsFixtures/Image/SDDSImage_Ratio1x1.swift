SDDSImage(
    image: Image(systemName: "photo"),
    appearance: Image.ratio_1_1.appearance
)
.frame(maxWidth: 120)
