SDDSCarousel(
    selection: $selection,
    pageCount: 5
) { index in
    ZStack {
        RoundedRectangle(cornerRadius: 12)
            .fill(Color(.systemGray5))
        Text("Page \(index + 1)")
    }
    .frame(height: 120)
}
