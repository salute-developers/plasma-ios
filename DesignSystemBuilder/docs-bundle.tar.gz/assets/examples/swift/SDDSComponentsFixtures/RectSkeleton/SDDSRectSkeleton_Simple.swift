SDDSRectSkeleton()
