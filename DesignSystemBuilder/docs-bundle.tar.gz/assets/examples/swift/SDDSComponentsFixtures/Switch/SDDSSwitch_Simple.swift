SDDSSwitch(
    title: "Label",
    subtitle: "Description",
    isOn: $isOn,
    isEnabled: true,
    switchAccessibility: SwitchAccessibility()
)
