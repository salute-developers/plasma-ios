SDDSCard() {
    VStack(alignment: .leading, spacing: 8) {
        Text("Header")
        Text("Description")
    }
}
