SDDSChip(
    title: "Label",
    isEnabled: true,
    iconImage: nil,
    buttonImage: nil,
    removeAction: {}
)
