SDDSDropdownMenu() {
    Text("Выпадающий контент")
}
