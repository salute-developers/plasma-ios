SDDSTextField(
    value: $value,
    title: "Password",
    placeholder: "Enter password",
    secureEntry: true,
    keyboardType: .emailAddress
)
