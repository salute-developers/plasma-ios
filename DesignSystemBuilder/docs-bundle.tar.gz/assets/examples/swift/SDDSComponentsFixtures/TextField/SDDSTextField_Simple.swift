SDDSTextField(
    value: $value,
    title: "Title",
    placeholder: "Enter the text"
)
