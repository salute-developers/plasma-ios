let items = [
    TabBarItemData(content: nil, text: "Tab 1"),
    TabBarItemData(content: nil, text: "Tab 2")
]
return SDDSTabBar(
    items: items,
    selectedIndex: $selectedIndex
)
