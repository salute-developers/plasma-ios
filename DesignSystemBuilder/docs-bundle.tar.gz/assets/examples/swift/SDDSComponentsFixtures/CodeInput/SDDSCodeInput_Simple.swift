SDDSCodeInput(
    code: $code,
    groups: CodeFieldGroup.four,
    validation: CodeFieldDisabledValidation(),
    validationResult: $validationResult,
    caption: "Введите код из СМС",
    captionAlignment: .center
)
