SDDSBadge(
    label: "Label",
    image: nil,
    alignment: .leading,
    style: .basic
)
