SDDSCell(
    alignment: .center,
    label: "label",
    title: "title",
    subtitle: "subtitle",
    disclosureEnabled: false,
    leftContent: { EmptyView() },
    rightContent: { EmptyView() }
)
