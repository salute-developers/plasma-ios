let items = [
    TabBarItemData(content: nil, text: "Tab 1"),
    TabBarItemData(content: nil, text: "Tab 2")
]
return SDDSTabBarIsland(
    items: items,
    selectedIndex: $selectedIndex
)
