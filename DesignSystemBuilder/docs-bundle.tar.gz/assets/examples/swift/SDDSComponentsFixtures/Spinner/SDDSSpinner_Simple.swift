SDDSSpinner(isAnimating: true, appearance: Spinner.l.default.appearance)
