SDDSFormHorizontal() {
    SDDSFormItem(
        title: { Text("Left") },
        optional: { EmptyView() },
        titleCaption: { EmptyView() },
        caption: { EmptyView() },
        counter: { EmptyView() }
    ) {
        Text("Value 1")
    }
    SDDSFormItem(
        title: { Text("Right") },
        optional: { EmptyView() },
        titleCaption: { EmptyView() },
        caption: { EmptyView() },
        counter: { EmptyView() }
    ) {
        Text("Value 2")
    }
}
