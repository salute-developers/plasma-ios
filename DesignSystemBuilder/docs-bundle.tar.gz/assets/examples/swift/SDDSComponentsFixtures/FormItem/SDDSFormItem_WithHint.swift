SDDSFormItem(
    title: { Text("Title") },
    optional: { EmptyView() },
    titleCaption: { EmptyView() },
    caption: { EmptyView() },
    counter: { EmptyView() },
    hasHint: true,
    onHintPressed: { isTooltipPresented = true }
) {
    Text("Form Item Content")
}
.tooltip(
    isPresented: $isTooltipPresented,
    appearance: Tooltip.m.appearance,
    width: nil,
    text: "Tooltip text"
) {
    EmptyView()
}
