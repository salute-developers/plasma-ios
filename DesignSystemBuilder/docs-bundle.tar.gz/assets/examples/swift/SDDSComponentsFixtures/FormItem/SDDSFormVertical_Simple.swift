SDDSFormVertical() {
    SDDSFormItem(
        title: { Text("First") },
        optional: { EmptyView() },
        titleCaption: { EmptyView() },
        caption: { EmptyView() },
        counter: { EmptyView() }
    ) {
        Text("Value 1")
    }
    SDDSFormItem(
        title: { Text("Second") },
        optional: { EmptyView() },
        titleCaption: { EmptyView() },
        caption: { EmptyView() },
        counter: { EmptyView() }
    ) {
        Text("Value 2")
    }
}
