SDDSCheckbox(
    state: $state,
    title: "Value",
    subtitle: "Description",
    isEnabled: true
)
