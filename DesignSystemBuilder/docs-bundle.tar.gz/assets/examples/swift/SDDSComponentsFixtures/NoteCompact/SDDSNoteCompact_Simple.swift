SDDSNoteCompact(title: "Title", text: "Description")
    .environment(\.noteCompactAppearance, NoteCompact.m.appearance)
