SDDSProgressView(
    progress: $progress,
    isEnabled: true
)
