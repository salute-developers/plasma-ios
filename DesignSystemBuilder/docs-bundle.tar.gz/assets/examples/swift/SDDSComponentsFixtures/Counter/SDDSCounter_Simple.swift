SDDSCounter(
    text: "1",
    isAnimating: false,
    isHighlighted: false,
    isHovered: false,
    isSelected: false
)
