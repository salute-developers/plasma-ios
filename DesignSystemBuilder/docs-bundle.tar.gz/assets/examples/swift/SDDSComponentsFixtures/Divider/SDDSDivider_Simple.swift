SDDSDivider()
