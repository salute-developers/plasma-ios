SDDSNavigationBar(
    type: .mainPage(appearance: NavigationBarMainPage.hasBackground.appearance),
    title: "Главная",
    textPlacement: .bottom,
    textAlign: .center,
    contentPlacement: .bottom,
    actionStart: { EmptyView() },
    actionEnd: { EmptyView() },
    content: { Text("Контент") }
)
