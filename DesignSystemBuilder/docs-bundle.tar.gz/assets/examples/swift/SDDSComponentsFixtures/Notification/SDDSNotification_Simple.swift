Text("Trigger")
    .notification(
        isPresented: $isPresented,
        appearance: NotificationLoose.m.appearance,
        position: .topCenter,
        duration: 3.0
    ) {
        Text("Текст уведомления")
    }
