SDDSSegmentItem(
    title: "Title",
    subtitle: "Subtitle",
    iconAttributes: nil,
    isSelected: true,
    accessibility: SegmentItemAccessibility(),
    action: {}
)
