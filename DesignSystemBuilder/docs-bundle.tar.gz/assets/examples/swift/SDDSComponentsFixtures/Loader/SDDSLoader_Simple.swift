SDDSLoader(appearance: Loader.default.appearance)
    .environment(\.spinnerData, SDDSSpinnerData(
        isAnimating: true,
        appearance: Spinner.l.default.appearance
    ))
