SDDSTabItem(
    label: "Tab 1",
    value: nil,
    counterValue: nil,
    isSelected: false,
    isDisabled: false,
    orientation: .horizontal,
    appearance: TabItemDefault.l.appearance,
    startContent: { EmptyView() },
    contentRight: { EmptyView() },
    actionContent: { EmptyView() }
)
