SDDSAvatar(
    text: "JD",
    image: nil,
    placeholderImage: nil,
    status: .hidden,
    accessibility: AvatarAccessibility()
)
