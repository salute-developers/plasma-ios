SDDSPaginationDots(
    selectedIndex: 2,
    totalCount: 8,
    visibleCount: 5
)
