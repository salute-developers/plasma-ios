BasicButton(
    title: "Label",
    subtitle: "Value",
    iconAttributes: .init(image: Image.image("plasma"), alignment: .leading),
    isDisabled: false,
    isLoading: false,
    spinnerImage: Image.image("spinner"),
    layoutMode: .wrapContent,
    action: { print("Button did tap") }
)
