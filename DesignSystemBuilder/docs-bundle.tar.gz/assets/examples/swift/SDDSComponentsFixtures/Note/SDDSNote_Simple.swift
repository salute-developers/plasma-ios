SDDSNote(title: "Title", text: "Description")
    .environment(\.noteAppearance, Note.m.appearance)
