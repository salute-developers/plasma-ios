---
title: CheckBox
---

Настраиваемый чекбокс, который может быть настроен с помощью различных параметров.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `state` | `Binding<SelectionControlState>` | Состояние чекбокса |
| `title` | `String` | Текст заголовка для чекбокса |
| `subtitle` | `String?` | Текст подзаголовка для чекбокса |
| `isEnabled` | `Bool` | Флаг, указывающий, включен ли чекбокс |
| `images` | `SelectionControlStateImages?` | Изображения для различных состояний чекбокса |
| `appearance` | `CheckboxAppearance?` | Параметры внешнего вида чекбокса |
| `accessibility` | `SelectionControlAccessibility` | Параметры доступности для чекбокса |

## Окружение
- `checkboxAppearance`: Стандартные настройки внешнего вида чекбокса

## Примеры использования

### Базовый чекбокс

```swift
SDDSCheckbox(
    state: $state,
    title: "Value",
    subtitle: "Description",
    isEnabled: true
)
```

<!-- @screenshot: SDDSComponentsFixtures.CheckBox.SDDSCheckbox_Simple -->

## Стиль CheckBox

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
