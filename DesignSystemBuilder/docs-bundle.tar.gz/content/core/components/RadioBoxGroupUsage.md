---
title: RadioBoxGroup
---

Компонент представляет собой группу радиобоксов, настроенных с помощью RadioboxData.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `radioboxData` | `[RadioboxData]` | Массив данных для инициализации группы радиобоксов |
| `size` | `RadioboxGroupSizeConfiguration` | Конфигурация размеров группы (устаревший параметр) |
| `appearance` | `RadioboxGroupAppearance?` | Параметры внешнего вида группы радиобоксов (опционально) |

## Окружение
- `radioboxGroupAppearance`: Стандартные настройки внешнего вида группы радиобоксов

## Пример использования

```swift
let data = [
    RadioboxData(
        title: "Option 1",
        subtitle: "Description 1",
        isSelected: Binding(
            get: { selectedIndex == 0 },
            set: { if $0 { selectedIndex = 0 } }
        ),
        isEnabled: true,
        appearance: Radiobox.m.appearance,
        accessibility: SelectionControlAccessibility()
    ),
    RadioboxData(
        title: "Option 2",
        subtitle: "Description 2",
        isSelected: Binding(
            get: { selectedIndex == 1 },
            set: { if $0 { selectedIndex = 1 } }
        ),
        isEnabled: true,
        appearance: Radiobox.m.appearance,
        accessibility: SelectionControlAccessibility()
    )
]
return SDDSRadioboxGroup(
    radioboxData: data,
    size: SDDSRadioboxGroupSize.large,
    appearance: RadioboxGroup.m.appearance
)
```

<!-- @screenshot: SDDSComponentsFixtures.RadioBoxGroup.SDDSRadioboxGroup_Simple -->

## Стиль RadioBoxGroup

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
