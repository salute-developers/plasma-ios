---
title: ChipGroup
---

Компонент для отображения группы связанных чипов.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `data` | `[ChipData]` | Массив элементов чипов |
| `appearance` | `ChipGroupAppearance?` | Параметры внешнего вида группы чипов (опционально) |
| `flat` | `Bool` | Флаг плоского отображения группы |
| `height` | `Binding<CGFloat>` | Привязка к высоте группы |

## Окружение
- `chipGroupAppearance`: Стандартные настройки внешнего вида группы чипов

## Примеры использования

### Базовая группа чипов

```swift
let chipData = [
    ChipData(
        title: "Label",
        isEnabled: true,
        iconImage: nil,
        buttonImage: nil,
        accessibility: ChipAccessibility(),
        removeAction: {}
    ),
    ChipData(
        title: "Label 2",
        isEnabled: true,
        iconImage: nil,
        buttonImage: nil,
        accessibility: ChipAccessibility(),
        removeAction: {}
    )
]
return SDDSChipGroup(
    data: chipData,
    flat: false,
    height: .constant(0),
    gap: .dense
)
```

<!-- @screenshot: SDDSComponentsFixtures.ChipGroup.SDDSChipGroup_Simple -->

## Стиль ChipGroup

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
