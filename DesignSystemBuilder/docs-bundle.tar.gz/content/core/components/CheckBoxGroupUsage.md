---
title: CheckBoxGroup
---

Компонент для отображения группы связанных чекбоксов.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `behaviour` | `CheckboxGroupBehaviour` | Поведение группы чекбоксов |
| `appearance` | `CheckboxGroupAppearance?` | Параметры внешнего вида группы чекбоксов (опционально) |

## Окружение
- `checkboxGroupAppearance`: Стандартные настройки внешнего вида группы чекбоксов

## Примеры использования

### Иерархическая группа чекбоксов

```swift
let parentData = CheckboxData(
    state: $parentState,
    title: "Parent Label",
    subtitle: "Parent Description",
    isEnabled: true,
    appearance: Checkbox.m.default.appearance,
    accessibility: SelectionControlAccessibility()
)
let childData = [
    CheckboxData(
        state: $child1State,
        title: "Label 1",
        subtitle: "Description 1",
        isEnabled: true,
        appearance: Checkbox.m.default.appearance,
        accessibility: SelectionControlAccessibility()
    ),
    CheckboxData(
        state: $child2State,
        title: "Label 2",
        subtitle: "Description 2",
        isEnabled: true,
        appearance: Checkbox.m.default.appearance,
        accessibility: SelectionControlAccessibility()
    )
]
return SDDSCheckboxGroup(
    behaviour: .hierarchical(parent: parentData, child: childData),
    size: SDDSCheckboxGroupSize.large,
    appearance: CheckboxGroup.m.appearance
)
```

<!-- @screenshot: SDDSComponentsFixtures.CheckBoxGroup.SDDSCheckboxGroup_Simple -->

## Стиль CheckBoxGroup

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
