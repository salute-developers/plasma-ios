---
title: Switch
---

Настраиваемый переключатель, который может быть настроен с помощью различных параметров.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `title` | `String` | Текст заголовка для переключателя |
| `subtitle` | `String` | Текст подзаголовка для переключателя |
| `isOn` | `Binding<Bool>` | Связка состояния включения/выключения переключателя |
| `isEnabled` | `Bool` | Флаг, указывающий, включен ли переключатель |
| `appearance` | `SwitchAppearance?` | Параметры внешнего вида переключателя |
| `switchAccessibility` | `SwitchAccessibility` | Параметры доступности для переключателя |

## Окружение
- `switchAppearance`: Стандартные настройки внешнего вида переключателя

## Пример использования

```swift
SDDSSwitch(
    title: "Label",
    subtitle: "Description",
    isOn: $isOn,
    isEnabled: true,
    switchAccessibility: SwitchAccessibility()
)
```

<!-- @screenshot: SDDSComponentsFixtures.Switch.SDDSSwitch_Simple -->

## Стиль Switch

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
