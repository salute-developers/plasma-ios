---
title: Cell
---

Компонент для отображения строки с различными типами контента и возможностью настройки выравнивания.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|-----------|
| `appearance` | `CellAppearance?` | Параметры внешнего вида ячейки (опционально) |
| `alignment` | `CellContentAlignment` | Выравнивание контента (top/center/bottom) |
| `label` | `String` | Текст метки |
| `title` | `String` | Основной текст |
| `subtitle` | `String` | Дополнительный текст |
| `disclosureEnabled` | `Bool` | Включить отображение disclosure |
| `disclosureImage` | `Image?` | Изображение для disclosure |
| `disclosureText` | `String` | Текст для disclosure |
| `leftContent` | `ViewBuilder` | Контент слева |
| `rightContent` | `ViewBuilder` | Контент справа |

## Окружение
- `cellAppearance`: Стандартные настройки внешнего вида ячейки

## Выравнивание контента (CellContentAlignment)

`CellContentAlignment` определяет возможные варианты выравнивания контента в ячейке:

- `top`: Контент выравнивается по верхней границе ячейки
- `center`: Контент выравнивается по центру ячейки
- `bottom`: Контент выравнивается по нижней границе ячейки

## Примеры использования

### Базовая ячейка

```swift
SDDSCell(
    alignment: .center,
    label: "label",
    title: "title",
    subtitle: "subtitle",
    disclosureEnabled: false,
    leftContent: { EmptyView() },
    rightContent: { EmptyView() }
)
```

<!-- @screenshot: SDDSComponentsFixtures.Cell.SDDSCell_Simple -->

## Стиль Cell

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
