---
title: Select
---

Компонент выбора значения из выпадающего списка с поддержкой режимов `single` и `multiple`, а также триггера в виде `TextField` или `Button`.

## Параметры

| Параметр | Тип | Описание |
|----------|-----|----------|
| `triggerStyle` | `SelectTriggerStyle` | Визуальный тип триггера (`.textField` или `.button`) |
| `text` | `String` | Текст выбранного значения (обычно для `single`) |
| `chips` | `[ChipData]` | Выбранные значения в виде чипов (обычно для `multiple`) |
| `title` | `String` | Заголовок триггера |
| `optionalTitle` | `String` | Дополнительный заголовок |
| `placeholder` | `String` | Placeholder, если выбор пустой |
| `caption` | `String` | Подпись под триггером |
| `textBefore` | `String` | Префикс текста |
| `textAfter` | `String` | Суффикс текста |
| `disabled` | `Bool` | Полностью отключает компонент |
| `readOnly` | `Bool` | Режим только чтения |
| `appearance` | `SelectAppearance?` | Кастомный внешний вид |
| `isDropdownPresented` | `Binding<Bool>` | Состояние открытия/закрытия dropdown |
| `options` | `[SelectOption]` | Элементы списка |
| `selectionMode` | `SelectSelectionMode?` | Режим выбора (`single`/`multiple`) |
| `closeOnSingleSelection` | `Bool` | Закрывать ли dropdown после выбора в `single` |
| `isLoading` | `Bool` | Показывает контент загрузки |
| `shouldShowEmptyState` | `Bool` | Показывает empty state при пустом списке |
| `placementMode` | `PopoverPlacementMode` | Режим позиционирования dropdown |
| `onOptionTap` | `((Int) -> Void)?` | Callback выбора элемента по индексу |
| `headerContent` | `() -> HeaderContent` | Слот для заголовка списка |
| `footerContent` | `() -> FooterContent` | Слот для футера списка |
| `loaderContent` | `() -> LoaderContent` | Слот для лоадера |
| `emptyStateContent` | `() -> EmptyStateContent` | Слот для empty state |

## Дополнительно

- `SelectOption` описывает элемент списка и хранит `id`, `title`, `subtitle`, `isSelected`, `isEnabled`.
- Для внешнего управления состоянием открытия можно использовать `SDDSSelectState`.
- В режиме `multiple` для `button` длинный текст выбранных значений обрезается с `...`, сохраняя фиксированную ширину кнопки.

## Примеры использования

### Single с TextField trigger

```swift
SDDSSelect(
    triggerStyle: .textField(TextFieldData(
        title: "City",
        placeholder: "Select city",
        appearance: SelectSingleNormal.l.appearance.textFieldAppearance
    )),
    text: selectedTitle,
    appearance: SelectSingleNormal.l.appearance,
    isDropdownPresented: $isDropdownPresented,
    options: options,
    selectionMode: .single,
    onOptionTap: { index in
        handleSingleSelection(at: index)
    }
)
```

<!-- @screenshot: SDDSComponentsFixtures.Select.SDDSSelect_SingleTextField -->

### Multiple с Button trigger

```swift
SDDSSelect(
    triggerStyle: .button(
        ButtonData(
            title: "Select cities",
            appearance: SelectMultipleNormal.l.appearance.buttonAppearance,
            layoutMode: .fixedWidth(.packed),
            action: {}
        )
    ),
    chips: chips,
    appearance: SelectMultipleNormal.l.appearance,
    isDropdownPresented: $isDropdownPresented,
    options: options,
    selectionMode: .multiple,
    onOptionTap: { index in
        handleMultipleSelection(at: index)
    }
)
.frame(width: 280, alignment: .leading)
```

<!-- @screenshot: SDDSComponentsFixtures.Select.SDDSSelect_MultipleButton -->

## Стиль Select

В большинстве случаев подходят готовые сгенерированные стили темы; при необходимости стиль можно собрать вручную из токенов.

:::warning
У компонента нет готовых стилей темы. Если нужен стиль, обратитесь в поддержку.
:::
